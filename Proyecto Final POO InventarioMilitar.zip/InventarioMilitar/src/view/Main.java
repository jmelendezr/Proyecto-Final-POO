package view;

import service.ConexionSQLite;

import javax.swing.SwingUtilities;

/** Profe, para ejecutar primero descargue el archivo .jar que esta en la carpeta lib de
este proyecto y añadalo como dependencia en la estructura de proyecto**/

/**
 * Clase principal que inicia la aplicación.
 */
public class Main {
    public static void main(String[] args) {
        // Asegurarse de que las tablas existan al iniciar la aplicación
        ConexionSQLite.crearTablas();

        // Ejecutar la interfaz gráfica
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                VentanaLogin login = new VentanaLogin();
                login.setVisible(true);
            }
        });
    }
}