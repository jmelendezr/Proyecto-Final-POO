package view;

import model.Usuario;
import service.UsuarioDAO;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Ventana de registro de nuevos usuarios.
 */
public class VentanaRegistro extends JFrame {

    private JTextField txtUsuario;
    private JPasswordField txtClave;
    private JComboBox<String> cmbRol;
    private JButton btnRegistrar;
    private JButton btnVolver;

    private JFrame ventanaLogin; // Referencia a la ventana de login para volver

    public VentanaRegistro(JFrame ventanaLogin) {
        this.ventanaLogin = ventanaLogin;
        setTitle("Registrar Nuevo Usuario");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Cierra solo esta ventana
        setLocationRelativeTo(null); // Centra la ventana
        setResizable(false);

        initComponents();
        addListeners();
    }

    private void initComponents() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblTitulo = new JLabel("Registro de Usuario", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 16));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(lblTitulo, gbc);

        JLabel lblUsuario = new JLabel("Usuario:");
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        panel.add(lblUsuario, gbc);

        txtUsuario = new JTextField(15);
        gbc.gridx = 1;
        gbc.gridy = 1;
        panel.add(txtUsuario, gbc);

        JLabel lblClave = new JLabel("Clave:");
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(lblClave, gbc);

        txtClave = new JPasswordField(15);
        gbc.gridx = 1;
        gbc.gridy = 2;
        panel.add(txtClave, gbc);

        JLabel lblRol = new JLabel("Rol:");
        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(lblRol, gbc);

        String[] roles = {"soldado", "admin"}; // "soldado" por defecto para nuevos registros
        cmbRol = new JComboBox<>(roles);
        gbc.gridx = 1;
        gbc.gridy = 3;
        panel.add(cmbRol, gbc);

        btnRegistrar = new JButton("Registrar");
        btnRegistrar.setBackground(new Color(60, 179, 113)); // MediumSeaGreen
        btnRegistrar.setForeground(Color.WHITE);
        btnRegistrar.setFocusPainted(false);
        btnRegistrar.setFont(new Font("Arial", Font.BOLD, 12));
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        panel.add(btnRegistrar, gbc);

        btnVolver = new JButton("Volver a Login");
        btnVolver.setBackground(new Color(105, 105, 105)); // DimGray
        btnVolver.setForeground(Color.WHITE);
        btnVolver.setFocusPainted(false);
        btnVolver.setFont(new Font("Arial", Font.BOLD, 12));
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        panel.add(btnVolver, gbc);

        add(panel);
    }

    private void addListeners() {
        btnRegistrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registrarUsuario();
            }
        });

        btnVolver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                volverALogin();
            }
        });

        // Al cerrar esta ventana, se asegura de que la ventana de login se vuelva visible
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                volverALogin();
            }
        });
    }

    private void registrarUsuario() {
        String nombreUsuario = txtUsuario.getText();
        String clave = new String(txtClave.getPassword());
        String rol = (String) cmbRol.getSelectedItem();

        if (nombreUsuario.isEmpty() || clave.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, ingresa usuario y clave.", "Error de Registro", JOptionPane.WARNING_MESSAGE);
            return;
        }

        UsuarioDAO usuarioDAO = new UsuarioDAO();
        if (usuarioDAO.existeUsuario(nombreUsuario)) {
            JOptionPane.showMessageDialog(this, "El nombre de usuario ya existe. Por favor, elige otro.", "Error de Registro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Usuario nuevoUsuario = new Usuario(nombreUsuario, clave, rol);
        if (usuarioDAO.registrarUsuario(nuevoUsuario)) {
            JOptionPane.showMessageDialog(this, "Usuario registrado exitosamente.", "Registro Exitoso", JOptionPane.INFORMATION_MESSAGE);
            volverALogin(); // Vuelve a la ventana de login después del registro exitoso
        } else {
            JOptionPane.showMessageDialog(this, "Error al registrar usuario. Inténtalo de nuevo.", "Error de Registro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void volverALogin() {
        this.dispose(); // Cierra esta ventana
        if (ventanaLogin != null) {
            ventanaLogin.setVisible(true); // Muestra la ventana de login
        }
    }
}