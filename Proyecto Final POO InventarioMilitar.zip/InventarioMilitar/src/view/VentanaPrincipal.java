package view;

import model.Arma;
import model.Municion; // Importar la nueva clase Municion
import model.Usuario;
import service.ArmaDAO;
import service.MunicionDAO; // Importar la nueva clase MunicionDAO

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

/**
 * Ventana principal que muestra el inventario y permite registrar armas y municiones.
 * El contenido visible depende del rol del usuario.
 */
public class VentanaPrincipal extends JFrame {

    private Usuario usuarioActual;
    private JTabbedPane tabbedPane; // Usar JTabbedPane para armas y municiones

    // Componentes para la pestaña de Armas
    private JTable tablaInventarioArmas;
    private DefaultTableModel modeloTablaArmas;
    private JTextField txtNombreArma;
    private JTextField txtTipoArma;
    private JSpinner spCantidadArma;
    private JButton btnRegistrarArma;

    // Componentes para la pestaña de Municiones
    private JTable tablaInventarioMuniciones;
    private DefaultTableModel modeloTablaMuniciones;
    private JTextField txtNombreMunicion;
    private JTextField txtTipoMunicion;
    private JSpinner spCantidadMunicion;
    private JButton btnRegistrarMunicion;

    private JButton btnCerrarSesion;

    public VentanaPrincipal(Usuario usuario) {
        this.usuarioActual = usuario;
        setTitle("Inventario Militar - Sesión de: " + usuario.getNombreUsuario() + " (" + usuario.getRol() + ")");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centra la ventana
        setResizable(true);

        initComponents();
        addListeners();
        cargarInventario(); // Carga el inventario inicial (armas)
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Panel superior para el título y botón de cerrar sesión
        JPanel topPanel = new JPanel(new BorderLayout());
        JLabel lblTitulo = new JLabel("Inventario de Equipamiento Militar", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 20));
        topPanel.add(lblTitulo, BorderLayout.CENTER);

        btnCerrarSesion = new JButton("Cerrar Sesión");
        btnCerrarSesion.setBackground(new Color(220, 20, 60)); // Crimson
        btnCerrarSesion.setForeground(Color.WHITE);
        btnCerrarSesion.setFocusPainted(false);
        topPanel.add(btnCerrarSesion, BorderLayout.EAST);
        mainPanel.add(topPanel, BorderLayout.NORTH);

        // JTabbedPane para separar Armas y Municiones
        tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Arial", Font.BOLD, 14));

        // Pestaña de Armas
        JPanel panelArmas = new JPanel(new BorderLayout());
        modeloTablaArmas = new DefaultTableModel(new Object[]{"ID", "Nombre", "Tipo", "Cantidad", "Registrado por"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tablaInventarioArmas = new JTable(modeloTablaArmas);
        tablaInventarioArmas.setFillsViewportHeight(true);
        tablaInventarioArmas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        panelArmas.add(new JScrollPane(tablaInventarioArmas), BorderLayout.CENTER);

        JPanel panelRegistroArma = new JPanel(new GridBagLayout());
        panelRegistroArma.setBorder(BorderFactory.createTitledBorder("Registrar Nueva Arma"));
        GridBagConstraints gbcArma = new GridBagConstraints();
        gbcArma.insets = new Insets(5, 5, 5, 5);
        gbcArma.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblNombreArma = new JLabel("Nombre:");
        gbcArma.gridx = 0; gbcArma.gridy = 0;
        panelRegistroArma.add(lblNombreArma, gbcArma);
        txtNombreArma = new JTextField(15);
        gbcArma.gridx = 1; gbcArma.gridy = 0;
        panelRegistroArma.add(txtNombreArma, gbcArma);

        JLabel lblTipoArma = new JLabel("Tipo:");
        gbcArma.gridx = 0; gbcArma.gridy = 1;
        panelRegistroArma.add(lblTipoArma, gbcArma);
        txtTipoArma = new JTextField(15);
        gbcArma.gridx = 1; gbcArma.gridy = 1;
        panelRegistroArma.add(txtTipoArma, gbcArma);

        JLabel lblCantidadArma = new JLabel("Cantidad:");
        gbcArma.gridx = 0; gbcArma.gridy = 2;
        panelRegistroArma.add(lblCantidadArma, gbcArma);
        spCantidadArma = new JSpinner(new SpinnerNumberModel(1, 1, 10000, 1));
        gbcArma.gridx = 1; gbcArma.gridy = 2;
        panelRegistroArma.add(spCantidadArma, gbcArma);

        btnRegistrarArma = new JButton("Registrar Arma");
        btnRegistrarArma.setBackground(new Color(70, 130, 180));

        btnRegistrarArma.setForeground(Color.WHITE);
        btnRegistrarArma.setFocusPainted(false);
        gbcArma.gridx = 0; gbcArma.gridy = 3;
        gbcArma.gridwidth = 2;
        panelRegistroArma.add(btnRegistrarArma, gbcArma);
        panelArmas.add(panelRegistroArma, BorderLayout.SOUTH);

        tabbedPane.addTab("Armas", panelArmas);

        // Pestaña de Municiones (NUEVA PESTAÑA)
        JPanel panelMuniciones = new JPanel(new BorderLayout());
        modeloTablaMuniciones = new DefaultTableModel(new Object[]{"ID", "Nombre", "Tipo", "Cantidad", "Registrado por"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tablaInventarioMuniciones = new JTable(modeloTablaMuniciones);
        tablaInventarioMuniciones.setFillsViewportHeight(true);
        tablaInventarioMuniciones.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        panelMuniciones.add(new JScrollPane(tablaInventarioMuniciones), BorderLayout.CENTER);

        JPanel panelRegistroMunicion = new JPanel(new GridBagLayout());
        panelRegistroMunicion.setBorder(BorderFactory.createTitledBorder("Registrar Nueva Munición"));
        GridBagConstraints gbcMunicion = new GridBagConstraints();
        gbcMunicion.insets = new Insets(5, 5, 5, 5);
        gbcMunicion.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblNombreMunicion = new JLabel("Nombre:");
        gbcMunicion.gridx = 0; gbcMunicion.gridy = 0;
        panelRegistroMunicion.add(lblNombreMunicion, gbcMunicion);
        txtNombreMunicion = new JTextField(15);
        gbcMunicion.gridx = 1; gbcMunicion.gridy = 0;
        panelRegistroMunicion.add(txtNombreMunicion, gbcMunicion);

        JLabel lblTipoMunicion = new JLabel("Tipo:");
        gbcMunicion.gridx = 0; gbcMunicion.gridy = 1;
        panelRegistroMunicion.add(lblTipoMunicion, gbcMunicion);
        txtTipoMunicion = new JTextField(15);
        gbcMunicion.gridx = 1; gbcMunicion.gridy = 1;
        panelRegistroMunicion.add(txtTipoMunicion, gbcMunicion);

        JLabel lblCantidadMunicion = new JLabel("Cantidad:");
        gbcMunicion.gridx = 0; gbcMunicion.gridy = 2;
        panelRegistroMunicion.add(lblCantidadMunicion, gbcMunicion);
        spCantidadMunicion = new JSpinner(new SpinnerNumberModel(1, 1, 10000, 1));
        gbcMunicion.gridx = 1; gbcMunicion.gridy = 2;
        panelRegistroMunicion.add(spCantidadMunicion, gbcMunicion);

        btnRegistrarMunicion = new JButton("Registrar Munición");
        btnRegistrarMunicion.setBackground(new Color(70, 130, 180)); // SteelBlue
        btnRegistrarMunicion.setForeground(Color.WHITE);
        btnRegistrarMunicion.setFocusPainted(false);
        gbcMunicion.gridx = 0; gbcMunicion.gridy = 3;
        gbcMunicion.gridwidth = 2;
        panelRegistroMunicion.add(btnRegistrarMunicion, gbcMunicion);
        panelMuniciones.add(panelRegistroMunicion, BorderLayout.SOUTH);

        tabbedPane.addTab("Municiones", panelMuniciones);

        mainPanel.add(tabbedPane, BorderLayout.CENTER); // Añadir el tabbedPane al panel principal

        add(mainPanel);
    }

    private void addListeners() {
        btnCerrarSesion.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cerrarSesion();
            }
        });

        btnRegistrarArma.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registrarNuevaArma();
            }
        });

        btnRegistrarMunicion.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registrarNuevaMunicion();
            }
        });

        // Listener para recargar el inventario cuando se cambia de pestaña
        tabbedPane.addChangeListener(e -> cargarInventario());
    }

    private void cargarInventario() {
        // Limpiar ambas tablas antes de cargar
        modeloTablaArmas.setRowCount(0);
        modeloTablaMuniciones.setRowCount(0);

        ArmaDAO armaDAO = new ArmaDAO();
        MunicionDAO municionDAO = new MunicionDAO(); // Instanciar el DAO de municiones

        List<Arma> armas;
        List<Municion> municiones;

        if ("admin".equals(usuarioActual.getRol())) {
            armas = armaDAO.obtenerTodasArmas();
            municiones = municionDAO.obtenerTodasMuniciones(); // Obtener todas las municiones para admin
        } else { // soldado
            armas = armaDAO.obtenerArmasPorUsuario(usuarioActual.getNombreUsuario());
            municiones = municionDAO.obtenerMunicionesPorUsuario(usuarioActual.getNombreUsuario()); // Obtener solo las municiones del soldado
        }

        // Cargar armas en la tabla de armas
        for (Arma arma : armas) {
            modeloTablaArmas.addRow(new Object[]{
                arma.getId(),
                arma.getNombre(),
                arma.getTipo(),
                arma.getCantidad(),
                arma.getUsuarioRegistro()
            });
        }

        // Cargar municiones en la tabla de municiones
        for (Municion municion : municiones) {
            modeloTablaMuniciones.addRow(new Object[]{
                municion.getId(),
                municion.getNombre(),
                municion.getTipo(),
                municion.getCantidad(),
                municion.getUsuarioRegistro()
            });
        }
    }

    private void registrarNuevaArma() {
        String nombre = txtNombreArma.getText().trim();
        String tipo = txtTipoArma.getText().trim();
        int cantidad = (int) spCantidadArma.getValue();

        if (nombre.isEmpty() || tipo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, ingresa el nombre y tipo del arma.", "Error de Registro", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Arma nuevaArma = new Arma(nombre, tipo, cantidad, usuarioActual.getNombreUsuario());
        ArmaDAO armaDAO = new ArmaDAO();

        if (armaDAO.registrarArma(nuevaArma)) {
            JOptionPane.showMessageDialog(this, "Arma registrada exitosamente.", "Registro Exitoso", JOptionPane.INFORMATION_MESSAGE);
            // Limpiar campos después del registro
            txtNombreArma.setText("");
            txtTipoArma.setText("");
            spCantidadArma.setValue(1);
            cargarInventario(); // Recargar la tabla para mostrar la nueva arma
        } else {
            JOptionPane.showMessageDialog(this, "Error al registrar el arma. Inténtalo de nuevo.", "Error de Registro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void registrarNuevaMunicion() {
        String nombre = txtNombreMunicion.getText().trim();
        String tipo = txtTipoMunicion.getText().trim();
        int cantidad = (int) spCantidadMunicion.getValue();

        if (nombre.isEmpty() || tipo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, ingresa el nombre y tipo de la munición.", "Error de Registro", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Municion nuevaMunicion = new Municion(nombre, tipo, cantidad, usuarioActual.getNombreUsuario());
        MunicionDAO municionDAO = new MunicionDAO();

        if (municionDAO.registrarMunicion(nuevaMunicion)) {
            JOptionPane.showMessageDialog(this, "Munición registrada exitosamente.", "Registro Exitoso", JOptionPane.INFORMATION_MESSAGE);
            // Limpiar campos después del registro
            txtNombreMunicion.setText("");
            txtTipoMunicion.setText("");
            spCantidadMunicion.setValue(1);
            cargarInventario(); // Recargar la tabla para mostrar la nueva munición
        } else {
            JOptionPane.showMessageDialog(this, "Error al registrar la munición. Inténtalo de nuevo.", "Error de Registro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cerrarSesion() {
        int confirm = JOptionPane.showConfirmDialog(this, "¿Estás seguro de que quieres cerrar sesión?", "Cerrar Sesión", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            VentanaLogin ventanaLogin = new VentanaLogin();
            ventanaLogin.setVisible(true);
            this.dispose(); // Cierra la ventana principal
        }
    }
}