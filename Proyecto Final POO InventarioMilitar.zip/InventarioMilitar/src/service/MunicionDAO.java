package service;

import model.Municion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase para el acceso a datos de la tabla 'municiones'.
 */
public class MunicionDAO {

    /**
     * Registra una nueva munición en la base de datos.
     * @param municion El objeto Municion a registrar.
     * @return true si el registro fue exitoso, false en caso contrario.
     */
    public boolean registrarMunicion(Municion municion) {
        String sql = "INSERT INTO municiones (nombre, tipo, cantidad, usuario_registro) VALUES (?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = ConexionSQLite.conectar();
            if (conn == null) return false;

            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, municion.getNombre());
            pstmt.setString(2, municion.getTipo());
            pstmt.setInt(3, municion.getCantidad());
            pstmt.setString(4, municion.getUsuarioRegistro());
            pstmt.executeUpdate();
            System.out.println("Munición '" + municion.getNombre() + "' registrada por " + municion.getUsuarioRegistro() + " exitosamente.");
            return true;
        } catch (SQLException e) {
            System.err.println("Error al registrar munición: " + e.getMessage());
            return false;
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                ConexionSQLite.cerrarConexion(conn);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Obtiene todas las municiones registradas en el sistema.
     * @return Una lista de objetos Municion.
     */
    public List<Municion> obtenerTodasMuniciones() {
        List<Municion> municiones = new ArrayList<>();
        String sql = "SELECT id, nombre, tipo, cantidad, usuario_registro FROM municiones";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = ConexionSQLite.conectar();
            if (conn == null) return municiones;

            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                Municion municion = new Municion(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("tipo"),
                    rs.getInt("cantidad"),
                    rs.getString("usuario_registro")
                );
                municiones.add(municion);
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener todas las municiones: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                ConexionSQLite.cerrarConexion(conn);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return municiones;
    }

    /**
     * Obtiene las municiones registradas por un usuario específico.
     * @param nombreUsuario El nombre de usuario del cual se quieren obtener las municiones.
     * @return Una lista de objetos Municion registrados por el usuario.
     */
    public List<Municion> obtenerMunicionesPorUsuario(String nombreUsuario) {
        List<Municion> municiones = new ArrayList<>();
        String sql = "SELECT id, nombre, tipo, cantidad, usuario_registro FROM municiones WHERE usuario_registro = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = ConexionSQLite.conectar();
            if (conn == null) return municiones;

            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, nombreUsuario);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                Municion municion = new Municion(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("tipo"),
                    rs.getInt("cantidad"),
                    rs.getString("usuario_registro")
                );
                municiones.add(municion);
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener municiones por usuario: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                ConexionSQLite.cerrarConexion(conn);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return municiones;
    }
}