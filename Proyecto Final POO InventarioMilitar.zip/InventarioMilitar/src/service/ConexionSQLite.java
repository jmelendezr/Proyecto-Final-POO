package service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Clase para gestionar la conexión a la base de datos SQLite y la creación de tablas.
 */
public class ConexionSQLite {

    private static final String URL = "jdbc:sqlite:inventario_militar.db"; // Nombre del archivo de la base de datos

    /**
     * Establece una conexión con la base de datos SQLite.
     * @return Objeto Connection si la conexión es exitosa, null en caso contrario.
     */
    public static Connection conectar() {
        Connection conn = null;
        try {
            // Carga el driver JDBC de SQLite
            Class.forName("org.sqlite.JDBC");
            // Establece la conexión
            conn = DriverManager.getConnection(URL);
            System.out.println("Conexión a SQLite establecida.");
        } catch (ClassNotFoundException e) {
            System.err.println("Error: Driver JDBC de SQLite no encontrado. Asegúrate de que el JAR esté en el classpath.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("Error al conectar a la base de datos SQLite: " + e.getMessage());
            e.printStackTrace();
        }
        return conn;
    }

    /**
     * Cierra la conexión a la base de datos.
     * @param conn La conexión a cerrar.
     */
    public static void cerrarConexion(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
                System.out.println("Conexión a SQLite cerrada.");
            } catch (SQLException e) {
                // Llamar a printStackTrace() por separado
                System.err.println("Error al cerrar la conexión a la base de datos: " + e.getMessage()); //
                e.printStackTrace(); // Imprime el stack trace completo
            }
        }
    }

    /**
     * Crea las tablas 'usuarios', 'armas' y 'municiones' si no existen.
     */
    public static void crearTablas() {
        Connection conn = null;
        Statement stmt = null;
        try {
            conn = conectar();
            if (conn != null) {
                stmt = conn.createStatement();

                // SQL para crear la tabla usuarios
                String sqlUsuarios = "CREATE TABLE IF NOT EXISTS usuarios (" +
                                     "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                                     "nombre_usuario TEXT NOT NULL UNIQUE," +
                                     "clave TEXT NOT NULL," +
                                     "rol TEXT NOT NULL)";
                stmt.execute(sqlUsuarios);
                System.out.println("Tabla 'usuarios' verificada/creada.");

                // SQL para crear la tabla armas
                String sqlArmas = "CREATE TABLE IF NOT EXISTS armas (" +
                                  "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                                  "nombre TEXT NOT NULL," +
                                  "tipo TEXT NOT NULL," +
                                  "cantidad INTEGER NOT NULL," +
                                  "usuario_registro TEXT NOT NULL," +
                                  "FOREIGN KEY (usuario_registro) REFERENCES usuarios(nombre_usuario))"; // Clave foránea al nombre de usuario
                stmt.execute(sqlArmas);
                System.out.println("Tabla 'armas' verificada/creada.");

                // SQL para crear la tabla municiones
                String sqlMuniciones = "CREATE TABLE IF NOT EXISTS municiones (" +
                                       "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                                       "nombre TEXT NOT NULL," +
                                       "tipo TEXT NOT NULL," +
                                       "cantidad INTEGER NOT NULL," +
                                       "usuario_registro TEXT NOT NULL," +
                                       "FOREIGN KEY (usuario_registro) REFERENCES usuarios(nombre_usuario))";
                stmt.execute(sqlMuniciones);
                System.out.println("Tabla 'municiones' verificada/creada.");
            }
        } catch (SQLException e) {
            System.err.println("Error al crear tablas: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null) stmt.close();
                cerrarConexion(conn);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}