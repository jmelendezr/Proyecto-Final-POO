package service;

import model.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Clase para el acceso a datos de la tabla 'usuarios'.
 */
public class UsuarioDAO {

    /**
     * Registra un nuevo usuario en la base de datos.
     * @param usuario El objeto Usuario a registrar.
     * @return true si el registro fue exitoso, false en caso contrario.
     */
    public boolean registrarUsuario(Usuario usuario) {
        String sql = "INSERT INTO usuarios (nombre_usuario, clave, rol) VALUES (?, ?, ?)";
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = ConexionSQLite.conectar();
            if (conn == null) return false;

            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, usuario.getNombreUsuario());
            pstmt.setString(2, usuario.getClave());
            pstmt.setString(3, usuario.getRol());
            pstmt.executeUpdate();
            System.out.println("Usuario " + usuario.getNombreUsuario() + " registrado exitosamente.");
            return true;
        } catch (SQLException e) {
            System.err.println("Error al registrar usuario: " + e.getMessage());
            return false;
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                ConexionSQLite.cerrarConexion(conn);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Intenta iniciar sesión con el nombre de usuario y la clave proporcionados.
     * @param nombreUsuario El nombre de usuario.
     * @param clave La clave.
     * @return El objeto Usuario si las credenciales son válidas, null en caso contrario.
     */
    public Usuario iniciarSesion(String nombreUsuario, String clave) {
        String sql = "SELECT id, nombre_usuario, clave, rol FROM usuarios WHERE nombre_usuario = ? AND clave = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Usuario usuario = null;
        try {
            conn = ConexionSQLite.conectar();
            if (conn == null) return null;

            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, nombreUsuario);
            pstmt.setString(2, clave);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                usuario = new Usuario(
                    rs.getInt("id"),
                    rs.getString("nombre_usuario"),
                    rs.getString("clave"),
                    rs.getString("rol")
                );
                System.out.println("Inicio de sesión exitoso para " + nombreUsuario);
            } else {
                System.out.println("Credenciales inválidas para " + nombreUsuario);
            }
        } catch (SQLException e) {
            System.err.println("Error al iniciar sesión: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                ConexionSQLite.cerrarConexion(conn);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return usuario;
    }

    /**
     * Verifica si un nombre de usuario ya existe en la base de datos.
     * @param nombreUsuario El nombre de usuario a verificar.
     * @return true si el usuario existe, false en caso contrario.
     */
    public boolean existeUsuario(String nombreUsuario) {
        String sql = "SELECT COUNT(*) FROM usuarios WHERE nombre_usuario = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = ConexionSQLite.conectar();
            if (conn == null) return false;

            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, nombreUsuario);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            System.err.println("Error al verificar existencia de usuario: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                ConexionSQLite.cerrarConexion(conn);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return false;
    }
}