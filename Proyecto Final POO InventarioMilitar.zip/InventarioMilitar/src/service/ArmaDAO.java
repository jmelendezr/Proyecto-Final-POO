package service;

import model.Arma;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase para el acceso a datos de la tabla 'armas'.
 */
public class ArmaDAO {

    /**
     * Registra una nueva arma en la base de datos.
     * @param arma El objeto Arma a registrar.
     * @return true si el registro fue exitoso, false en caso contrario.
     */
    public boolean registrarArma(Arma arma) {
        String sql = "INSERT INTO armas (nombre, tipo, cantidad, usuario_registro) VALUES (?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = ConexionSQLite.conectar();
            if (conn == null) return false;

            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, arma.getNombre());
            pstmt.setString(2, arma.getTipo());
            pstmt.setInt(3, arma.getCantidad());
            pstmt.setString(4, arma.getUsuarioRegistro());
            pstmt.executeUpdate();
            System.out.println("Arma '" + arma.getNombre() + "' registrada por " + arma.getUsuarioRegistro() + " exitosamente.");
            return true;
        } catch (SQLException e) {
            System.err.println("Error al registrar arma: " + e.getMessage());
            return false;
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                ConexionSQLite.cerrarConexion(conn);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Obtiene todas las armas registradas en el sistema.
     * @return Una lista de objetos Arma.
     */
    public List<Arma> obtenerTodasArmas() {
        List<Arma> armas = new ArrayList<>();
        String sql = "SELECT id, nombre, tipo, cantidad, usuario_registro FROM armas";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = ConexionSQLite.conectar();
            if (conn == null) return armas;

            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                Arma arma = new Arma(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("tipo"),
                    rs.getInt("cantidad"),
                    rs.getString("usuario_registro")
                );
                armas.add(arma);
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener todas las armas: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                ConexionSQLite.cerrarConexion(conn);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return armas;
    }

    /**
     * Obtiene las armas registradas por un usuario específico.
     * @param nombreUsuario El nombre de usuario del cual se quieren obtener las armas.
     * @return Una lista de objetos Arma registrados por el usuario.
     */
    public List<Arma> obtenerArmasPorUsuario(String nombreUsuario) {
        List<Arma> armas = new ArrayList<>();
        String sql = "SELECT id, nombre, tipo, cantidad, usuario_registro FROM armas WHERE usuario_registro = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = ConexionSQLite.conectar();
            if (conn == null) return armas;

            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, nombreUsuario);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                Arma arma = new Arma(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("tipo"),
                    rs.getInt("cantidad"),
                    rs.getString("usuario_registro")
                );
                armas.add(arma);
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener armas por usuario: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                ConexionSQLite.cerrarConexion(conn);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return armas;
    }
}